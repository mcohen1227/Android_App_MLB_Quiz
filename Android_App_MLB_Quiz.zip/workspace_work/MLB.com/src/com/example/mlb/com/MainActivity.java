package com.example.mlb.com;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;

public class MainActivity extends Activity {
	
	public final static String EXTRA_MESSAGE = "com.example.mlb.com.MESSAGE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
    /** Called when the user clicks the Start Quiz button*/
    public void startQuiz(View view) {
    	Intent intent = new Intent(this, DisplayQuizActivity.class);
    	intent.putExtra(EXTRA_MESSAGE, "Starting Quiz...");
    	startActivity(intent);
    }
    
    /** Called when the user clicks the Web button*/
    public void goToWeb(View view) {
    	//Launch MLB.com in Web Browser
    	Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.mlb.com"));
    	startActivity(browserIntent);
    }
    
    /** Called when the user clicks the About button*/
    public void aboutInfo(View view) {
    	//Display info message
    	new AlertDialog.Builder(this)
    		.setTitle("About")
    		.setMessage("Author: Michael Cohen \nFor MLB.com Interview")
    		.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener(){
    			public void onClick(DialogInterface dialog, int which){
    				//Close Dialog
				}
    		})
    		.setIcon(R.drawable.ic_launcher)
    		.show();
    }
}
