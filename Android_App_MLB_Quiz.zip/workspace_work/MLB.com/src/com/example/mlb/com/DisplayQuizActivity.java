package com.example.mlb.com;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class DisplayQuizActivity extends Activity {
	//constants
	public final static int QUESTION_NUMBER = 5;

	//instance variables
	TextView teamName;
	ImageView teamLogo;
	Button next_button;
	RadioButton radio_button;
	RadioGroup radioGroup;
	
	//Division Array
	//0=alEast,1=alCentral,2=alWest
	//3=nlEast,4=nlCentral,5=nlWest
	int[] divisionArray;
	int[] imageArray;
	String[] nameArray;
	int[] noRepeatTeams;
	
	int currentDivision;
	int selectedDivision;
	int correctCount;
	int questionCount;
	
	Intent mainIntent;
	
	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_display_quiz);
		// Show the Up button in the action bar.
		setupActionBar();
		
		divisionArray = new int[30];
		imageArray = new int[30];
		nameArray = new String[30];
		
		noRepeatTeams = new int[QUESTION_NUMBER];
		int i = 0;
		while (i < QUESTION_NUMBER) {
			noRepeatTeams[i] = -1;
			i++;
		}
		//alEast
		divisionArray[0]=0;//orio
		imageArray[0]=R.drawable.orio;
		nameArray[0]="Team Name: Baltimore Orioles";
		divisionArray[1]=0;//redsox
		imageArray[1]=R.drawable.redsox;
		nameArray[1]="Team Name: Boston Red Sox";
		divisionArray[2]=0;//yank
		imageArray[2]=R.drawable.yank;
		nameArray[2]="Team Name: New York Yankees";
		divisionArray[3]=0;//ray
		imageArray[3]=R.drawable.ray;
		nameArray[3]="Team Name: Tampa Bay Rays";
		divisionArray[4]=0;//blue
		imageArray[4]=R.drawable.blue;
		nameArray[4]="Team Name: Toronto Blue Jays";
		//alCentral
		divisionArray[5]=1;//whitesox
		imageArray[5]=R.drawable.whitesox;
		nameArray[5]="Team Name: Chicago White Sox";
		divisionArray[6]=1;//ind
		imageArray[6]=R.drawable.ind;
		nameArray[6]="Team Name: Cleveland Indians";
		divisionArray[7]=1;//tiger
		imageArray[7]=R.drawable.tiger;
		nameArray[7]="Team Name: Detroit Tigers";
		divisionArray[8]=1;//royal
		imageArray[8]=R.drawable.royal;
		nameArray[8]="Team Name: Kansas City Royals";
		divisionArray[9]=1;//twin
		imageArray[9]=R.drawable.twin;
		nameArray[9]="Team Name: Minnesota Twins";
		//alWest
		divisionArray[10]=2;//astro
		imageArray[10]=R.drawable.astro;
		nameArray[10]="Team Name: Houston Astros";
		divisionArray[11]=2;//angel
		imageArray[11]=R.drawable.angel;
		nameArray[11]="Team Name: Los Angeles Angels of Anaheim";
		divisionArray[12]=2;//ath
		imageArray[12]=R.drawable.ath;
		nameArray[12]="Team Name: Oakland Athletics";
		divisionArray[13]=2;//mari
		imageArray[13]=R.drawable.mari;
		nameArray[13]="Team Name: Seattle Mariners";
		divisionArray[14]=2;//rang
		imageArray[14]=R.drawable.rang;
		nameArray[14]="Team Name: Texas Rangers";
		//nlEast
		divisionArray[15]=3;//brave
		imageArray[15]=R.drawable.brave;
		nameArray[15]="Team Name: Atlanta Braves";
		divisionArray[16]=3;//marlin
		imageArray[16]=R.drawable.marlin;
		nameArray[16]="Team Name: Miami Marlins";
		divisionArray[17]=3;//met
		imageArray[17]=R.drawable.met;
		nameArray[17]="Team Name: New York Mets";
		divisionArray[18]=3;//phil
		imageArray[18]=R.drawable.phil;
		nameArray[18]="Team Name: Philadelphia Phillies";
		divisionArray[19]=3;//nation
		imageArray[19]=R.drawable.nation;
		nameArray[19]="Team Name: Washington Nationals";
		//nlCentral
		divisionArray[20]=4;//cubs
		imageArray[20]=R.drawable.cubs;
		nameArray[20]="Team Name: Chicago Cubs";
		divisionArray[21]=4;//reds
		imageArray[21]=R.drawable.reds;
		nameArray[21]="Team Name: Cincinnati Reds";
		divisionArray[22]=4;//brewer
		imageArray[22]=R.drawable.brewer;
		nameArray[22]="Team Name: Milwaukee Brewers";
		divisionArray[23]=4;//pira
		imageArray[23]=R.drawable.pira;
		nameArray[23]="Team Name: Pittsburgh Pirates";
		divisionArray[24]=4;//card
		imageArray[24]=R.drawable.card;
		nameArray[24]="Team Name: St. Louis Cardinals";
		//nlWest
		divisionArray[25]=5;//dback
		imageArray[25]=R.drawable.dback;
		nameArray[25]="Team Name: Arizona Diamondbacks";
		divisionArray[26]=5;//rock
		imageArray[26]=R.drawable.rock;
		nameArray[26]="Team Name: Colorado Rockies";
		divisionArray[27]=5;//dodger
		imageArray[27]=R.drawable.dodger;
		nameArray[27]="Team Name: Los Angeles Dodgers";
		divisionArray[28]=5;//padr
		imageArray[28]=R.drawable.padr;
		nameArray[28]="Team Name: San Diego Padres";
		divisionArray[29]=5;//giant
		imageArray[29]=R.drawable.giant;
		nameArray[29]="Team Name: San Francisco Giants";
		
		//Randomly select team
		int randomNumber = 0;
		currentDivision = 0;
		selectedDivision = 0;
		correctCount = 0;
		
		//Generate Random Number
		randomNumber = (int)(Math.random() * 29);
		
		teamName = new TextView(this);
		teamName = (TextView)findViewById(R.id.teamName);
		teamName.setText(nameArray[randomNumber]);
		
		teamLogo = new ImageView(this);
		teamLogo = (ImageView)findViewById(R.id.teamLogo);
		teamLogo.setImageResource(imageArray[randomNumber]);
		
		currentDivision = divisionArray[randomNumber];
		
		questionCount = 0;
		next_button = new Button(this);
		next_button = (Button)findViewById(R.id.next_button);
		
		radio_button = new RadioButton(this);
		radioGroup = new RadioGroup(this);
		
		mainIntent = new Intent(this, MainActivity.class);
		
		//Display info message
    	new AlertDialog.Builder(this)
    		.setTitle("Objective")
    		.setMessage("Select the correct division for 5 Major League Baseball teams. \n\n" +
    				"Aim for a perfect score!")
    		.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener(){
    			public void onClick(DialogInterface dialog, int which){
    				//Close Dialog
				}
    		})
    		.setIcon(R.drawable.ic_launcher)
    		.show();
	}

	/**
	 * Set up the {@link android.app.ActionBar}, if the API is available.
	 */
	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	private void setupActionBar() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
			getActionBar().setDisplayHomeAsUpEnabled(true);
		}
	}
	
	/** Called when the user clicks the Next Team button*/
    public void nextTeam(View view) {
    	boolean checked = false;
    	
    	radio_button = (RadioButton)findViewById(R.id.alEast);
    	checked = (checked || radio_button.isChecked());
    	radio_button = (RadioButton)findViewById(R.id.nlEast);
    	checked = (checked || radio_button.isChecked());
    	radio_button = (RadioButton)findViewById(R.id.alCentral);
    	checked = (checked || radio_button.isChecked());
    	radio_button = (RadioButton)findViewById(R.id.nlCentral);
    	checked = (checked || radio_button.isChecked());
    	radio_button = (RadioButton)findViewById(R.id.alWest);
    	checked = (checked || radio_button.isChecked());
    	radio_button = (RadioButton)findViewById(R.id.nlWest);
    	checked = (checked || radio_button.isChecked());
    	
    	if (!checked) {
    		//Display info message
        	new AlertDialog.Builder(this)
        		.setTitle("Select")
        		.setMessage("Please select a division.")
        		.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener(){
        			public void onClick(DialogInterface dialog, int which){
        				//Close Dialog
    				}
        		})
        		.setIcon(R.drawable.ic_launcher)
        		.show();
    		
    		return;
    	}
    	
    	questionCount++;
    	
    	if (currentDivision == selectedDivision)
			correctCount++;
    	
    	if (questionCount == (QUESTION_NUMBER)) {
    		//Display info message
        	new AlertDialog.Builder(this)
        		.setTitle("Finish")
        		.setMessage("You have correctly answered " + correctCount + " of " + QUESTION_NUMBER + " questions. \n\n" +
        				"Thanks for playing!")
        		.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener(){
        			public void onClick(DialogInterface dialog, int which){
        				startActivity(mainIntent);
    				}
        		})
        		.setIcon(R.drawable.ic_launcher)
        		.setCancelable(false)
        		.show();
    	}
    	else {
    		//Randomly select team
    		int randomNumber = 0;
    			
    		//Generate Random Number
    		boolean repeatNumber = true;
    		boolean repeats = false;
    		int x = 0;
    		while(repeatNumber) {    			
    			randomNumber = (int)(Math.random() * 29);
    			
    			while (x < QUESTION_NUMBER) {
    				if (noRepeatTeams[x] == randomNumber)
    					repeats = true;
    				x++;
    			}
    			x = 0;
    			if (!repeats) {
    				repeatNumber = false;
    				noRepeatTeams[questionCount] = randomNumber;
    			}
    			repeats = false;
    		}
    			
    		teamName.setText(nameArray[randomNumber]);
    			
    		teamLogo.setImageResource(imageArray[randomNumber]);
    			
    		currentDivision = divisionArray[randomNumber];
    	
    		if (questionCount == QUESTION_NUMBER - 1) {
    			next_button.setText("Finish");    		    		        	
    		}
    	}
    	
    	//Reset Radio Buttons
    	radioGroup = (RadioGroup)findViewById(R.id.divisionGroup);
    	radioGroup.clearCheck();
    }
    
    public void onRadioButtonClicked(View view) {
    	// Is the button now checked?
    	boolean checked = ((RadioButton) view).isChecked();
    	
    	// Check which radio button was clicked
    	switch(view.getId()) {
    		case R.id.alEast:
    			if (checked)
    				selectedDivision = 0;
    			break;
    		case R.id.nlEast:
    			if (checked)
    				selectedDivision = 3;
    			break;
    		case R.id.alCentral:
    			if (checked)
    				selectedDivision = 1;
    			break;
    		case R.id.nlCentral:
    			if (checked)
    				selectedDivision = 4;
    			break;
    		case R.id.alWest:
    			if (checked)
    				selectedDivision = 2;
    			break;
    		case R.id.nlWest:
    			if (checked)
    				selectedDivision = 5;
    			break;
    	}
    }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.display_quiz, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			// This ID represents the Home or Up button. In the case of this
			// activity, the Up button is shown. Use NavUtils to allow users
			// to navigate up one level in the application structure. For
			// more details, see the Navigation pattern on Android Design:
			//
			// http://developer.android.com/design/patterns/navigation.html#up-vs-back
			//
			NavUtils.navigateUpFromSameTask(this);
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

}
